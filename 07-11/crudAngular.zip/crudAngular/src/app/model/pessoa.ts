export interface Pessoa {
    id?: number,
    nome: string,
    idade: number,
    profissao: string
}
