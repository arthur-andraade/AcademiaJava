package br.atos.petshop.enums;

public enum RoleEnum {
	ROLE_ATENDIMENTO_PETSHOP,
	ROLE_CLIENTE_PETSHOP
}
