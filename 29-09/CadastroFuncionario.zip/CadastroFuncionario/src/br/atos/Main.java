package br.atos;

import br.atos.telas.MenuInicial;

public class Main {

	public static void main(String[] args) {

		MenuInicial menuInicial = new MenuInicial();
		menuInicial.iniciarMenuInicial();
		
	}

}
